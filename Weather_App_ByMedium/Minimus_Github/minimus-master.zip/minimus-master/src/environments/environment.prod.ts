export const environment = {
  production: true,
  appID: '',
  gKey: '',
  config: {
    apiKey: '',
    authDomain: '',
    databaseURL: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: ''
  }
};
